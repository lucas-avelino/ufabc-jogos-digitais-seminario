using System.Collections;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

/// <summary>
/// Singleton controller for the map zoom system.
/// Smoothly animates the camera to a target area with a blur effect during
/// the transition (blur peaks at the midpoint, then clears as the camera settles).
///
/// SETUP:
///  1. Attach this component to any persistent GameObject (e.g. GameManager).
///  2. Assign the Camera field, or leave it empty to auto-use Camera.main.
///  3. Create a Global Volume in the scene:
///       · Add Component → Volume  →  set Profile to a new VolumeProfile
///       · Add Override → Post-processing → Depth of Field
///       · Set Mode to Gaussian
///       · Tick the "Max Radius" checkbox override (value does not matter, it's
///         driven by this script at runtime)
///       · Assign that Volume to the Blur Volume field below.
///     If no Volume is assigned, the zoom animation still plays — just without blur.
///  4. Call ZoomToArea(position, size) from a MapZoomArea component.
///  5. Call ZoomOut() (or press Escape / right-click) to return to the overview.
/// </summary>
public class CameraZoomController : MonoBehaviour
{
    [Header("Camera")]
    [Tooltip("Leave empty to use Camera.main.")]
    [SerializeField] private Camera _camera;

    [Header("Zoom Animation")]
    [Tooltip("Total duration of the zoom transition in seconds.")]
    [SerializeField] private float _zoomDuration = 0.7f;
    [Tooltip("Easing curve for both position and ortho-size. X = time (0-1), Y = value (0-1).")]
    [SerializeField] private AnimationCurve _zoomCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

    [Header("Blur (URP DepthOfField — Gaussian mode)")]
    [Tooltip("Global Volume that contains a DepthOfField (Gaussian) override. Leave empty to skip blur.")]
    [SerializeField] private Volume _blurVolume;
    [Tooltip("Maximum Gaussian Max Radius value reached at the midpoint of the transition.")]
    [SerializeField] [Range(0f, 1f)] private float _maxBlurRadius = 0.6f;

    [Header("Overview (auto-captured at Start)")]
    [Tooltip("Snapshotted from the camera's transform at Start. Override here if needed.")]
    [SerializeField] private Vector3 _overviewPosition;
    [SerializeField] private float   _overviewOrthoSize = 10f;
    [SerializeField] private bool    _allowEscapeToZoomOut      = true;
    [SerializeField] private bool    _allowRightClickToZoomOut  = true;

    // ── Runtime state ────────────────────────────────────────────────────────
    private bool _isTransitioning = false;
    public bool IsTransitioning => _isTransitioning;
    private bool _isZoomedIn      = false;
    private DepthOfField _dof;   // URP post-process component, may be null

    // ── Unity lifecycle ──────────────────────────────────────────────────────
    private void Start()
    {
        if (_camera == null)
            _camera = Camera.main;

        _overviewPosition  = _camera.transform.position;
        _overviewOrthoSize = _camera.orthographicSize;

        // Grab DepthOfField from the assigned Volume, if any
        if (_blurVolume != null && _blurVolume.profile != null)
        {
            _blurVolume.profile.TryGet(out _dof);
            if (_dof == null)
                Debug.LogWarning("[CameraZoomController] Volume has no DepthOfField override. Add one (Gaussian mode) to enable blur.");
        }

        SetBlur(0f);
    }

    private void Update()
    {
        if (_isTransitioning || !_isZoomedIn) return;

        if (_allowEscapeToZoomOut && Input.GetKeyDown(KeyCode.Escape))
            ZoomOut();
        if (_allowRightClickToZoomOut && Input.GetMouseButtonDown(1))
            ZoomOut();
    }

    // ── Public API ───────────────────────────────────────────────────────────

    /// <summary>Smoothly zoom the camera to a world position with a given ortho size.</summary>
    public void ZoomToArea(Vector3 worldPosition, float orthoSize)
    {
        if (_isTransitioning) return;
        StartCoroutine(ZoomCoroutine(worldPosition, orthoSize));
    }

    /// <summary>Return the camera to its original overview position and size.</summary>
    public void ZoomOut()
    {
        if (_isTransitioning || !_isZoomedIn) return;
        StartCoroutine(ZoomCoroutine(_overviewPosition, _overviewOrthoSize, isZoomOut: true));
    }

    // ── Core coroutine ────────────────────────────────────────────────────────
    private IEnumerator ZoomCoroutine(Vector3 targetPosition, float targetOrthoSize, bool isZoomOut = false)
    {
        _isTransitioning = true;

        Vector3 fromPos  = _camera.transform.position;
        float   fromSize = _camera.orthographicSize;
        Vector3 toPos    = new Vector3(targetPosition.x, targetPosition.y, fromPos.z);

        float elapsed = 0f;
        while (elapsed < _zoomDuration)
        {
            elapsed += Time.deltaTime;
            float raw = Mathf.Clamp01(elapsed / _zoomDuration);
            float t   = _zoomCurve.Evaluate(raw);

            // ── Camera ────────────────────────────────────────────
            _camera.transform.position = Vector3.Lerp(fromPos, toPos, t);
            _camera.orthographicSize   = Mathf.Lerp(fromSize, targetOrthoSize, t);

            // ── Blur: triangle wave — peaks at the midpoint (raw = 0.5) ──
            float blurT = 1f - Mathf.Abs(raw * 2f - 1f); // 0 → 1 → 0
            SetBlur(_maxBlurRadius * blurT);

            yield return null;
        }

        // Snap to exact target and clear blur
        _camera.transform.position = toPos;
        _camera.orthographicSize   = targetOrthoSize;
        SetBlur(0f);

        _isZoomedIn      = !isZoomOut;
        _isTransitioning = false;
    }

    // ── Blur helper ───────────────────────────────────────────────────────────
    private void SetBlur(float radius)
    {
        if (_dof == null) return;
        _dof.active = radius > 0f;
        _dof.gaussianMaxRadius.value = radius;
    }
}
