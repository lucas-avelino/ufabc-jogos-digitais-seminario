using System;
using UnityEngine;

/// <summary>
/// Place this component on any GameObject that represents a clickable area on
/// the map.  Requires a Collider (3D) or Collider2D (2D) to receive OnMouseDown.
///
/// SETUP:
///  1. Create a GameObject for each zoom area (e.g. an invisible plane / sprite
///     covering the region of interest).
///  2. Attach a Collider / Collider2D to it.
///  3. Attach this MapZoomArea component.
///  4. In the Inspector, set:
///       · Target Ortho Size  – how tight the zoom is (smaller = more zoomed in)
///       · Camera Offset      – optional world-space offset from this object's
///                              pivot to where the camera should centre.
///  5. Make sure a CameraZoomController exists in the scene.
/// </summary>
public class MapZoomArea : MonoBehaviour
{
    [Header("Zoom Target")]
    [Tooltip("Orthographic size the camera will animate to. Smaller = more zoomed in.")]
    [SerializeField] private float _targetOrthoSize = 3f;
    public float TargetOrthoSize => _targetOrthoSize;

    [Tooltip("World-space offset from this object's position to the camera centre point. " +
             "Useful when the pivot is not exactly at the visual centre of the area.")]
    [SerializeField] private Vector3 _cameraOffset = Vector3.zero;
    public Vector3 CameraTargetPos => transform.position + _cameraOffset;

    [Header("Debug")]
    [Tooltip("Draw a gizmo sphere at the computed camera target position.")]
    [SerializeField] private bool _showGizmo = true;

    [SerializeField] public bool _isZoomed = true;

    public event Action OnClicked;

    // ── Interaction ─────────────────────────────────────────────────────────

    private void OnMouseDown()
    {
      OnClicked?.Invoke();
        // if (CameraZoomController.Instance == null)
        // {
        //     Debug.LogWarning("[MapZoomArea] No CameraZoomController found in the scene.");
        //     return;
        // }

        // if (_isZoomed)
        // {
        //     Debug.Log("[MapZoomArea] Clicked on an inactive MapZoomArea. Ignoring.");
        //     return;
        // }

        // Vector3 target = transform.position + _cameraOffset;
        // CameraZoomController.Instance.ZoomToArea(target, _targetOrthoSize);
    }

    // ── Gizmo ────────────────────────────────────────────────────────────────
#if UNITY_EDITOR
    private void OnDrawGizmosSelected()
    {
        if (!_showGizmo) return;

        // Draw the camera target point
        Gizmos.color = new Color(0f, 0.8f, 1f, 0.9f);
        Vector3 target = transform.position + _cameraOffset;
        Gizmos.DrawWireSphere(target, 0.25f);
        Gizmos.DrawLine(transform.position, target);

        // Draw a rough rectangle representing the zoomed view area
        // (assumes orthographic camera, but gives a useful visual hint)
        float aspect = (float)Screen.width / Mathf.Max(Screen.height, 1);
        float h = _targetOrthoSize;
        float w = h * aspect;
        Gizmos.color = new Color(0f, 0.8f, 1f, 0.3f);
        Gizmos.DrawWireCube(target, new Vector3(w * 2f, h * 2f, 0.1f));
    }
#endif
}
